import 'package:flutter/cupertino.dart';

import 'app.dart';

void main() {
  runApp(MyApp());
}

